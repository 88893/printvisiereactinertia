import { Head } from "@inertiajs/react";
import { useState, useEffect, Suspense, lazy } from "react";
import React from "react";
import Layout from "../layouts/Layout";

const BreadcrumbArea = lazy(() =>
    import("../components/BreadcrumbArea/BreadcrumbArea")
);
const BackgroundImageHeader = lazy(() =>
    import("../components/TextBlock/BackgroundImageHeader")
);
const Gap = lazy(() => import("../components/TextBlock/Gap"));
const TextBlock = lazy(() => import("../components/TextBlock/TextBlock"));
const InnerContactArea = lazy(() =>
    import("../components/Contact/InnerContactArea")
);
const ImagesNext = lazy(() => import("../components/TextBlock/ImagesNext"));
const TextBlockImage = lazy(() =>
    import("../components/TextBlock/TextBlockImage")
);
const BrandAreaThree = lazy(() => import("../components/Brand/BrandAreaThree"));
const CommunityArea = lazy(() =>
    import("../components/CommunityArea/CommunityArea")
);
const PopOver = lazy(() => import("../components/TextBlock/PopOver"));
const ImageBlock = lazy(() => import("../components/TextBlock/ImageBlock"));
const NewsLetterAreaTwo = lazy(() =>
    import("../components/NewsLetter/NewsLetterAreaTwo")
);
const TeamAreaThree = lazy(() => import("../components/Team/TeamAreaThree"));
const AboutArea = lazy(() => import("../components/About/AboutArea"));
const BannerOne = lazy(() => import("../components/Banner/BannerOne"));
const ConsultationArea = lazy(() =>
    import("../components/Consultation/ConsultationArea")
);
const ProjectArea = lazy(() => import("../components/Project/ProjectArea"));
const ServicesArea = lazy(() =>
    import("../components/ServicesArea/ServicesArea")
);
const TeamArea = lazy(() => import("../components/Team/TeamArea"));
const TestimonialArea = lazy(() =>
    import("../components/Testimonial/TestimonialArea")
);
const BrandArea = lazy(() => import("../components/Brand/BrandArea"));
const ConsultationAreaTwo = lazy(() =>
    import("../components/Consultation/ConsultationAreaTwo")
);
const CounterAreaThree = lazy(() =>
    import("../components/CounterArea/CounterAreaThree")
);
const HistoryArea = lazy(() => import("../components/HistoryArea/HistoryArea"));
const InnerServicesArea = lazy(() =>
    import("../components/ServicesArea/InnerServicesArea")
);

const SuccessArea = lazy(() => import("../components/SuccessArea/SuccessArea"));
const TeamAreaTwo = lazy(() => import("../components/Team/TeamAreaTwo"));
const List = lazy(() => import("../components/TextBlock/List"));
const ComponentMap = {
    BreadcrumbArea,
    BackgroundImageHeader,
    TextBlock,
    ImageBlock,
    PopOver,
    TextBlockImage,
    InnerContactArea,
    BrandAreaThree,
    CommunityArea,
    NewsLetterAreaTwo,
    TeamAreaThree,
    AboutArea,
    BannerOne,
    ConsultationArea,
    ProjectArea,
    ServicesArea,
    TeamArea,
    TestimonialArea,
    BrandArea,
    ConsultationAreaTwo,
    CounterAreaThree,
    HistoryArea,
    InnerServicesArea,
    SuccessArea,
    TeamAreaTwo,
    ImagesNext,
    List,
    Gap,
};

const LoadingFallback = () => (
    <div className="component-loading-indicator">
        <div className="spinner">
            <div className="bounce1"></div>
            <div className="bounce2"></div>
            <div className="bounce3"></div>
        </div>
        <style jsx>{`
            .component-loading-indicator {
                display: flex;
                justify-content: center;
                align-items: center;
                min-height: 200px;
            }
            .spinner {
                margin: 100px auto 0;
                width: 70px;
                text-align: center;
            }
            .spinner > div {
                width: 18px;
                height: 18px;
                background-color: #333;
                border-radius: 100%;
                display: inline-block;
                animation: sk-bouncedelay 1.4s infinite ease-in-out both;
                margin: 0 3px;
            }
            .spinner .bounce1 {
                animation-delay: -0.32s;
            }
            .spinner .bounce2 {
                animation-delay: -0.16s;
            }
            @keyframes sk-bouncedelay {
                0%,
                80%,
                100% {
                    transform: scale(0);
                }
                40% {
                    transform: scale(1);
                }
            }
        `}</style>
    </div>
);

const renderComponent = (component) => {
    if (!component || !component.type) return null;

    const ComponentToRender = ComponentMap[component.type];

    if (!ComponentToRender) {
        console.warn(`Component ${component.type} not found in ComponentMap`);
        return null;
    }

    const childrenComponents = component.children?.map(renderComponent) || [];

    // Controleer of er een style-object is gedefinieerd
    const hasCustomStyles =
        component.style && Object.keys(component.style).length > 0;

    // Maak een kopie van de stijl om deze te kunnen aanpassen
    let styleToApply = { ...component.style };

    // Pas stijl toe op de props voor tekstkleur en tekst uitlijning
    let updatedProps = { ...component.props };

    if (hasCustomStyles) {
        // Voeg een styleClass toe aan de props voor tekstkleur en tekst uitlijning
        if (component.style.color) {
            updatedProps.textColor = component.style.color;
        }
        if (component.style.textAlign) {
            updatedProps.textAlign = component.style.textAlign;
        }
        if (component.style.fontSize) {
            updatedProps.fontSize = component.style.fontSize;
        }
        if (component.style.fontWeight) {
            updatedProps.fontWeight = component.style.fontWeight;
        }

        // Controleer of er padding of margin opties zijn en voeg deze samen tot een enkel CSS attribuut
        const paddingTop = component.style.paddingTop || "";
        const paddingRight = component.style.paddingRight || "";
        const paddingBottom = component.style.paddingBottom || "";
        const paddingLeft = component.style.paddingLeft || "";

        if (paddingTop || paddingRight || paddingBottom || paddingLeft) {
            styleToApply.padding =
                `${paddingTop} ${paddingRight} ${paddingBottom} ${paddingLeft}`.trim();

            // Verwijder de individuele padding-eigenschappen om dubbele stijlen te voorkomen
            delete styleToApply.paddingTop;
            delete styleToApply.paddingRight;
            delete styleToApply.paddingBottom;
            delete styleToApply.paddingLeft;
        }

        const marginTop = component.style.marginTop || "";
        const marginRight = component.style.marginRight || "";
        const marginBottom = component.style.marginBottom || "";
        const marginLeft = component.style.marginLeft || "";

        if (marginTop || marginRight || marginBottom || marginLeft) {
            styleToApply.margin =
                `${marginTop} ${marginRight} ${marginBottom} ${marginLeft}`.trim();

            // Verwijder de individuele margin-eigenschappen om dubbele stijlen te voorkomen
            delete styleToApply.marginTop;
            delete styleToApply.marginRight;
            delete styleToApply.marginBottom;
            delete styleToApply.marginLeft;
        }
    }

    // Render met of zonder stijlwrapper op basis van aanwezigheid van style
    return (
        <Suspense
            fallback={<LoadingFallback />}
            key={component.id || Math.random().toString(36)}
        >
            {hasCustomStyles ? (
                <div style={styleToApply} className="custom-styled-component">
                    <ComponentToRender {...updatedProps}>
                        {childrenComponents}
                    </ComponentToRender>
                </div>
            ) : (
                <ComponentToRender {...updatedProps}>
                    {childrenComponents}
                </ComponentToRender>
            )}
        </Suspense>
    );
};

const DynamicPage = ({ page }) => {
    const [pageLoadTime, setPageLoadTime] = useState(null);

    useEffect(() => {
        const startTime = performance.now();

        return () => {
            const endTime = performance.now();
            setPageLoadTime(endTime - startTime);
            console.log(`Page rendering took: ${endTime - startTime}ms`);
        };
    }, [page.components]);

    return (
        <>
            <Head>
                <title>{page.meta_title || page.title}</title>
                {page.meta_description && (
                    <meta name="description" content={page.meta_description} />
                )}
                {page.meta_keywords && (
                    <meta name="keywords" content={page.meta_keywords} />
                )}
                {page.meta_image && (
                    <>
                        <meta property="og:image" content={page.meta_image} />
                        <meta name="twitter:image" content={page.meta_image} />
                    </>
                )}
            </Head>

            {page.components && page.components.length > 0 ? (
                <Suspense
                    fallback={
                        <div className="page-loading">
                            Loading page content...
                        </div>
                    }
                >
                    <div className="dynamic-page-components">
                        {page.components.map(renderComponent)}
                    </div>
                </Suspense>
            ) : (
                <div dangerouslySetInnerHTML={{ __html: page.content || "" }} />
            )}

            {process.env.NODE_ENV !== "production" && pageLoadTime && (
                <div
                    style={{
                        position: "fixed",
                        bottom: 10,
                        right: 10,
                        background: "#f0f0f0",
                        padding: 8,
                        borderRadius: 4,
                        fontSize: 12,
                        boxShadow: "0 2px 4px rgba(0,0,0,0.1)",
                        zIndex: 9999,
                    }}
                ></div>
            )}
        </>
    );
};

DynamicPage.layout = (page) => (
    <Layout
        header={1}
        footer={1}
        className=""
        mainClassName=""
        children={page}
    />
);

export default DynamicPage;
